library(shiny)
library(datasets)
library(qicharts2)
library(ggplot2)
library(plotly)
library(googlesheets)
library(dplyr)

########################

ccsiero <-gs_title("ccsierologia")
ccmicro <-gs_title("ccmicrobiologia")

#ccsieroso<-gs_title("ccsierologiaSO")